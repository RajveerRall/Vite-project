# ModularTTS

A flexible, modular text-to-speech pipeline with support for multiple LLMs, parsers, and TTS providers.

## Features

- **Multiple LLM Support**: OpenAI GPT-4o, Gemini 2.0 Flash
- **Flexible Parsing**: Simple dialogue parser, intelligent casting parser, single narrator parser
- **TTS Providers**: OpenAI TTS, Cartesia TTS
- **Voice Casting**: Consistent character voice assignment across multiple texts
- **Usage Tracking**: Built-in usage tracking and analytics
- **OCR Support**: Extract text from images using Gemini OCR
- **TypeScript Support**: Full TypeScript definitions included

## Installation

```bash
npm install @your-scope/modular-tts
```

## Quick Start

```typescript
import { createPipeline } from '@your-scope/modular-tts';

// Create a pipeline with your API keys
const pipeline = createPipeline({
  llm: 'gpt-4o',
  parser: 'intelligentCastingParser',
  apiKeys: {
    openai: 'your-openai-api-key',
    cartesia: 'your-cartesia-api-key'
  },
  useVoiceCasting: true
});

// Process text
const result = await pipeline.process(`
"Hello there!" said John excitedly.
"I'm so glad to see you," replied Sarah with a smile.
`);

console.log(result.script);
// Output: [
//   { character: "John", dialogue: "Hello there!", gender: "male", provider: "cartesia", voiceId: "..." },
//   { character: "Sarah", dialogue: "I'm so glad to see you", gender: "female", provider: "cartesia", voiceId: "..." }
// ]
```

## API Reference

### Pipeline Options

```typescript
interface PipelineOptions {
  llm?: string;                    // LLM provider ('gpt-4o', 'gemini-2.0-flash')
  parser?: string;                  // Parser ('simpleDialogueParser', 'intelligentCastingParser', 'singleNarratorParser')
  apiKeys?: {
    openai?: string;
    gemini?: string;
    cartesia?: string;
  };
  useVoiceCasting?: boolean;        // Enable voice casting memory
}
```

### Built-in Parsers

- **`simpleDialogueParser`**: Basic dialogue extraction
- **`intelligentCastingParser`**: Advanced parsing with gender inference and voice casting
- **`singleNarratorParser`**: Converts all text to single narrator format

### Built-in LLM Providers

- **OpenAI**: GPT-4o, GPT-4o Mini
- **Gemini**: Gemini 2.0 Flash

### Built-in TTS Providers

- **OpenAI TTS**: Nova, Alloy, Echo, Fable, Onyx, Shimmer voices
- **Cartesia TTS**: Multiple high-quality voices

## Advanced Usage

### Custom Plugins

```typescript
import { ModularAIFactory, LLMPlugin } from '@your-scope/modular-tts';

// Create custom LLM plugin
const customLLM: LLMPlugin = {
  id: 'custom-llm',
  name: 'Custom LLM',
  async execute(prompt: string) {
    // Your custom LLM implementation
    return 'response';
  }
};

// Register with factory
const factory = new ModularAIFactory({
  // your config
});

factory.registerLLMPlugin(customLLM);
```

### Usage Tracking

```typescript
import { getUsageTracker } from '@your-scope/modular-tts';

const tracker = getUsageTracker();

// Get usage statistics
const stats = tracker.getStats();
console.log(`Total requests: ${stats.totalRequests}`);
console.log(`Total cost: $${stats.totalCost}`);
```

### Voice Casting

```typescript
import { CastingManager } from '@your-scope/modular-tts';

const castingManager = new CastingManager();

// Ensure voice cast for characters
const characters = [
  { character: 'John', gender: 'male' },
  { character: 'Sarah', gender: 'female' }
];

const characterMap = castingManager.ensureVoiceCast(characters);
// Returns map with voice assignments
```

## Environment Variables

Set these environment variables for automatic configuration:

```bash
OPENAI_API_KEY=your-openai-key
CARTESIA_API_KEY=your-cartesia-key
GEMINI_API_KEY=your-gemini-key
```

## License

MIT

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.